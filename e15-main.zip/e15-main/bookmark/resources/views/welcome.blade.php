<!doctype html>
<html lang='en'>

<head>
    <title>Bookmark</title>
    <meta charset='utf-8'>
</head>

<body>
    <h1>Bookmark</h1>
</body>

</html>