# Bookmark - P2
+ By: Caroline Im
+ Production URL: <http://bookmark.caroli.me>



## Outside resources

- https://www.php.net/manual/en/function.strrev.php
- https://www.php.net/manual/en/function.is-int.php
- https://www.php.net/manual/en/language.operators.assignment.php
- https://www.php.net/manual/en/function.ord.php 
- http://sticksandstones.kstrom.com/appen.html

## Notes for instructor