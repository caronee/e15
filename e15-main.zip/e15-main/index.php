<!doctype html>
<html lang='en'>

<head>
    <title>Hello from my XAMPP-powered server!</title>
    <meta charset='utf-8'>
</head>

<body>
    <h1>Hello from my XAMPP-powered server!</h1>
</body>

</html>