
# Project 1
+ By: Caroline
+ Production URL: <http://e15p1.caroli.me/>

## Outside resources

- https://www.php.net/manual/en/function.strrev.php
- https://www.php.net/manual/en/function.is-int.php
- https://www.php.net/manual/en/language.operators.assignment.php
- https://www.php.net/manual/en/function.ord.php 
- http://sticksandstones.kstrom.com/appen.html

## Notes for instructor

This was a trial by fire.

Just kept blindly copying the videos until things worked.

The php coding was probably the easiest part, although I did find it to be much more difficult to do design C. 

I do not know if I would be able to reproduce this on my own.

