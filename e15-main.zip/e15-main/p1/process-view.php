<!DOCTYPE html>
<html lang='en'>

<head>

    <title>Project 1</title>
    <meta charset='utf-8'>

</head>

<body>

    <div class='container'>

        <h1>String Processor - e15 Project 1</h1>
        <h2>Is Palindrome?</h2>
        <?php echo $result; ?>
        <h2>Vowel Count</h2>
        <?php echo $vowelCount; ?>
        <h2>Letter Shift</h2>
        <?php echo $result; ?>
    </div>


</body>

</html>