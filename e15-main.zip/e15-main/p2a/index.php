<!doctype html> 
<html lang='en'> 
    <head>     
    <title>Practice Application</title>
        <meta charset='utf-8'>     

        <link href=data:, rel=icon> 
    </head> 
    <body>
        <h1>Practice Application</h1>
        <h2>By: Caroline Im</h2>
        <p>edits</p>

        <?php echo 9+10; ?>

    </body> 
 </html>
