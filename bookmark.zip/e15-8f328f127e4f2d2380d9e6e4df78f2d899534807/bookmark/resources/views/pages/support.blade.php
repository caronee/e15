@extends('layouts/main')

@section('content')
<h1>Support</h1>

<p>Email: support@bookmark.com</p>
<p>Phone: 555-555-5555</p>
@endsection
