@extends('layouts/main')

@section('content')
<p>
    Welcome to Bookmark&mdash; an online book journal that lets you track and share a history of books you’ve read.
</p>
@endsection
