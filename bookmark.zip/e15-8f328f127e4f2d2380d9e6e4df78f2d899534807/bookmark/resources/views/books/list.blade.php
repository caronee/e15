@extends('layouts/main')

@section('title')
Your List
@endsection

@section('content')
<h1>Your List</h1>

<p>This page will display all the books on your list...</p>
@endsection
