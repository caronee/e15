<!doctype html>
<html lang='en'>

<head>

    <title></title>
    <meta charset='utf-8'>

</head>

<body>

    <h1>Results</h1>
    <?php echo $results; ?>

</body>

</html>