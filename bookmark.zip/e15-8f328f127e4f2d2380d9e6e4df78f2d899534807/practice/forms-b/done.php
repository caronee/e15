<?php

session_start();

$results = $_SESSION['results'];

require 'done-view.php';